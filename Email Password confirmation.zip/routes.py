from flask import Flask, render_template, request
from models import db, User
from forms import SignupForm



app = Flask(__name__)

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # this will stop  the warning displaying for  SQLAlchemy
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://localhost/learningflask' # with this line Now is connected to the DB
db.init_app(app) #to initialize to use the DB setup


app.secret_key = "development-key"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/signup", methods=['GET', "POST"])
def signup():
    form = SignupForm()

    if request.method =="POST":
        if form.validate() == False:
            return render_template('signup.html', form=form)
        else:
            newuser = User(form.first_name.data, form.last_name.data, form.email.data, form.password.data)
            db.session.add(newuser)
            db.session.commit()

            return "Success!"

    elif request.method == "GET":
      return render_template('signup.html', form=form)


if __name__ == "__main__":
    app.run(debug=True)
