from django.contrib import admin
from .models import Post

class PostAdmin(admin.ModelAdmin):
    list_display = ('Name', 'last_name', 'author', 'publish','status')
    list_filter = ('first_name', 'last_name', 'created')
    search_fields = ('Name', 'publish')
    ordering = ['last_name', 'status']
admin.site.register(Post)
