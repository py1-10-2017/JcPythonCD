from django.contrib import admin
from .models import Post


class PostAdmin(admin.ModelAdmin):
    list_display = ('Name','Dojo', 'author', 'publish', 'status')
    list_filter = ('status', 'created', 'publish', 'author')
    search_fields = ('Name', 'body')
    prepopulated_fields = {'Dojo' : ('Name',)} #  We now have told Django to pre-populate the slug field with the input of the title field using the pre-populated fields attribute.
    raw_id_fields = ('author', )
    date_hierarchy = 'publish'
    ordering = ['status', 'publish']
admin.site.register(Post, PostAdmin)

# Register your models here.
