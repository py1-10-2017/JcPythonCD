from flask_wtf import Form
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length


class SignupForm(Form):
    first_name = StringField("First Name", validators=[DataRequired("Pleaser Enter your First Name")])
    last_name = StringField("Last Name", validators=[DataRequired("Please Enter your Last Name")])
    email =  StringField("Email", validators=[DataRequired("Please Enter a Valid Email"), Email("Please Enter a Valid email Address.")])
    password = PasswordField("Password", validators=[DataRequired("Please Enter a Password"), Length(min=8, message="Password must be 8 characters")])
    submit = SubmitField("Send Information", validators=[DataRequired()])
