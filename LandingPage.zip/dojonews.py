from flask import Flask, render_template

app = Flask(__name__)
@app.route('/dojos/new')
def index():
    return render_template("dojo.html")
app.run(debug=True)
