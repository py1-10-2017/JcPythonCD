from django.contrib import admin
from .models import dojo
# Register your models here.


class dojoAdmin(admin.ModelAdmin):
    list_display = ['dojo_location', 'first_name', 'last_name', 'description']


admin.site.register(dojo, dojoAdmin)
