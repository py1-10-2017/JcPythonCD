from django.shortcuts import render, redirect
from django.http import HttpResponse
from datetime import datetime

#Jc recall that each function definate in here also have 2b in urls.py
def index(request):
    return HttpResponse('<p>Testing</p>' )
    #items = Item.objects.exclude(amout=0)return  render(request, 'blogs/index.html', {'items': items})
def new_display(request, id):
    #try:item = Item.objects.get(id=id)except Item.DoesNotExist:raise Http404('This item does not exist')return render(request, 'blogs/new_display.html',{'item':item,})
    return HttpResponse('<p>PlaceHolder to display a new form to create a new blog{0}</p>'.format(id))

def zone_time(request):
      context = {
        "time": datetime.now()
       }
      return render(request, "./timeZon.html", context)
