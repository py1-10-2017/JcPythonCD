from flask_wtf import Form
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

class SignupForm(Form):
    first_name = StringField('First name', validators=[DataRequired("Please enter your first Name")])
    language = StringField('language', validators=[DataRequired("Please enter a Language")])
    location =  StringField('location', validators=[DataRequired("Please add a Location")])
    comment = StringField('Comment', validators=[DataRequired("Valid Password")])
    submit = SubmitField('Bottom')
