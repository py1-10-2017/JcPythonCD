from flask import Flask, render_template, request
from forms import SignupForm


app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

app.secret_key = "development-key"

@app.route('/users', methods=['POST'])
def create_user():
    print "Got Post info"

    name = request.form['name']
    email = request.form['email']

    return redirect('/')


@app.route('/show')
def show_user():
    return render_template('user.html', name='Jay', email='kpatel@codingdojo.com')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()

    if request.method == 'POST':
        return "Success!"

    elif request.method == "GET":
        return render_template('signup.html', form=form)



   app.run(debug=True)
