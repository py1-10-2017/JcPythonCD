def Articles():
    articles = [
        {
            'id': 1,
            'title': 'Blog Number one',
            'body':'Lead to your experience for Coding Dojo',
            'author':'Jason Kennedy',
            'create_date':'01-04-2017'
        },
        {
            'id': 2,
            'title': 'Blog Number two',
            'body':'Lead to your experience for Coding Dojo',
            'author':'Jason Kennedy',
            'create_date':'01-04-2017'
        },
        {
            'id': 3,
            'title': 'Blog Number three',
            'body':'Lead to your experience for Coding Dojo',
            'author':'Jason Kennedy',
            'create_date':'01-04-2017'
        },
        {
            'id': 4,
            'title': 'Blog Number four',
            'body':'Lead to your experience for Coding Dojo',
            'author':'Jason Kennedy',
            'create_date':'01-04-2017'
        }
    ]
    return articles
