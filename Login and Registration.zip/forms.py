from flask_wtf import Form
from wtforms import StringField, PasswordField, SubmitField

#in order to use the valitor use this:
from wtforms.validators import DataRequired, Email, Length, EqualTo

class SignupForm(Form):
    first_name = StringField('First name', validators=[DataRequired("Please enter your First Name")])
    last_name = StringField('Last name', validators=[DataRequired("Please enter your Last Name")])
    email = StringField('Email', validators=[DataRequired("Please your Email properly, Thanks"),Email("Please Enter a Valid Email address")])
    password = PasswordField('Password', validators=[DataRequired("Please enter a valid Password"), Length(min=7, message="Password must be 7 characters long"), EqualTo('confirm', message='Password must match')])
    confirm = PasswordField('Repeat Password')
    submit = SubmitField('Sign Up')

class LoginForm(Form):
    email = StringField('Email',  validators=[DataRequired("Please Enter your Email address"), Email("Enter Please a Business email")])
    password = PasswordField('Password', validators=[DataRequired("Please enter your password.")])
    submit = SubmitField("Sign in")
